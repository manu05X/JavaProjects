package com.example.PlayerProfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayerProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
