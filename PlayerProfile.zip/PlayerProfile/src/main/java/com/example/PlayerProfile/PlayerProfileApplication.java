package com.example.PlayerProfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlayerProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlayerProfileApplication.class, args);
	}

}
